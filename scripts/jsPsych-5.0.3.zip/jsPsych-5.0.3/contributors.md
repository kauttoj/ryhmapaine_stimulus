The following people have contributed to the development of jsPsych by writing code, documentation, and/or suggesting major improvements (in alphabetical order):
* Jason Carpenter
* Josh de Leeuw - https://github.com/jodeleeuw
* Jonas Lambers
* Shane Martin - https://github.com/shamrt
* Adrian Oesch - https://github.com/adrianoesch
* Marian Sauter - https://github.com/mariansauter
* Tim Vergenz - https://github.com/vergenzt
* Erik Weitnauer - https://github.com/eweitnauer
